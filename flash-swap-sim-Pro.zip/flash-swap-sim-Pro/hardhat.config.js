require("@nomicfoundation/hardhat-toolbox");
const INFURA_KEY = process.env.INFURA_KEY || "";
const PRIVATE_KEY = process.env.DEPLOYER_KEY || "";
module.exports = {
  solidity: "0.8.19",
  networks: {
    hardhat: {},
    sepolia: {
      url: INFURA_KEY ? `https://sepolia.infura.io/v3/${INFURA_KEY}` : "",
      accounts: PRIVATE_KEY ? [PRIVATE_KEY] : []
    }
  }
};
