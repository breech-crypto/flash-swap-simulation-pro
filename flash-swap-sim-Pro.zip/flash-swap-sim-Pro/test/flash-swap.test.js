const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Flash-swap simulation", function () {
  it("provider lends and receives repayment+fee", async function () {
    const [deployer, user] = await ethers.getSigners();

    // Deploy mock token with 1M tokens to deployer
    const Mock = await ethers.getContractFactory("MockERC20");
    const mock = await Mock.deploy(ethers.utils.parseEther("1000000"));
    await mock.deployed();

    // Deploy provider and user borrower
    const Provider = await ethers.getContractFactory("FlashSwapProvider");
    const provider = await Provider.deploy();
    await provider.deployed();

    const Borrower = await ethers.getContractFactory("FlashSwapUser");
    const borrower = await Borrower.deploy();
    await borrower.deployed();

    // Fund provider with tokens from deployer
    await mock.transfer(provider.address, ethers.utils.parseEther("10000"));
    const providerBalance = await mock.balanceOf(provider.address);
    expect(providerBalance).to.equal(ethers.utils.parseEther("10000"));

    // Borrow amount
    const amount = ethers.utils.parseEther("1000");
    // call flashSwap
    await expect(provider.flashSwap(mock.address, amount, borrower.address, "0x"))
      .to.emit(provider, "FlashLoan");

    // after operation provider balance should be >= original + fee
    const feeBasisPoints = await provider.feeBasisPoints();
    const fee = amount.mul(feeBasisPoints).div(10000);
    const finalBalance = await mock.balanceOf(provider.address);
    expect(finalBalance).to.equal(ethers.utils.parseEther("10000").add(fee));
  });
});
