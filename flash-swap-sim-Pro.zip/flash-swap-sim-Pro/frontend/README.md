# Frontend - Flash Swap Simulator (React)

Minimal frontend to connect MetaMask and call the provider flashSwap function.
This is a demo UI. For real educational demos you should use a contract as the borrower.
