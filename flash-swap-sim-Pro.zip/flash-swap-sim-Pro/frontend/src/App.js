import React, { useState } from 'react';
import { ethers } from 'ethers';

function App() {
  const [status, setStatus] = useState('Not connected');
  const [providerAddress, setProviderAddress] = useState('');
  const [tokenAddress, setTokenAddress] = useState('');
  const [amount, setAmount] = useState('0');

  async function connect() {
    if (!window.ethereum) {
      setStatus('MetaMask not found');
      return;
    }
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    setStatus('Wallet connected');
  }

  async function triggerFlashSwap() {
    try {
      if (!window.ethereum) { setStatus('MetaMask required'); return; }
      const web3Provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = web3Provider.getSigner();
      const providerAbi = ["function flashSwap(address token,uint256 amount,address borrower,bytes calldata data)"];

      const contract = new ethers.Contract(providerAddress, providerAbi, signer);

      // use msg.sender as borrower (must be a contract in real demo)
      const tx = await contract.flashSwap(tokenAddress, ethers.utils.parseEther(amount), signer.getAddress(), '0x');
      setStatus('Transaction sent: ' + tx.hash);
      await tx.wait();
      setStatus('Flash swap executed: ' + tx.hash);
    } catch (e) {
      setStatus('Error: ' + (e.message || e));
    }
  }

  return (
    <div style={{padding:20}}>
      <h2>Flash Swap Simulator - Frontend</h2>
      <p>Status: {status}</p>
      <button onClick={connect}>Connect Wallet</button>
      <div style={{marginTop:10}}>
        <input placeholder="Provider address" value={providerAddress} onChange={e=>setProviderAddress(e.target.value)} style={{width:400}}/>
      </div>
      <div style={{marginTop:10}}>
        <input placeholder="Token address" value={tokenAddress} onChange={e=>setTokenAddress(e.target.value)} style={{width:400}}/>
      </div>
      <div style={{marginTop:10}}>
        <input placeholder="Amount (ETH units)" value={amount} onChange={e=>setAmount(e.target.value)} style={{width:200}}/>
      </div>
      <div style={{marginTop:10}}>
        <button onClick={triggerFlashSwap}>Trigger Flash Swap</button>
      </div>
    </div>
  );
}

export default App;
