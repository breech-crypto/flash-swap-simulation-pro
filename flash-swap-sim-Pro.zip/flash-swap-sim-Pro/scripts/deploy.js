const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with", deployer.address);

  const Mock = await hre.ethers.getContractFactory("MockERC20");
  const mock = await Mock.deploy(hre.ethers.utils.parseEther("1000000"));
  await mock.deployed();
  console.log("MockERC20 deployed to:", mock.address);

  const Provider = await hre.ethers.getContractFactory("FlashSwapProvider");
  const provider = await Provider.deploy();
  await provider.deployed();
  console.log("FlashSwapProvider deployed to:", provider.address);

  const Borrower = await hre.ethers.getContractFactory("FlashSwapUser");
  const borrower = await Borrower.deploy();
  await borrower.deployed();
  console.log("FlashSwapUser deployed to:", borrower.address);

  // transfer some mock tokens to provider for demo (from deployer)
  const tx = await mock.transfer(provider.address, hre.ethers.utils.parseEther("10000"));
  await tx.wait();
  console.log("Funded provider with 10000 tokens");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
